#include <stdio.h>

void switchover(int of lint n,int split) { int k

iffk<split)

else

}

void display(int o[], int n)

{ int k for(k=0;k<n;k++) (k%2==0)?printf("%d % %, a[k] printf("%d",0[k]); }

void main()
{
int h=(30,40,50,20,10,5), switchover(h,6,3);

display(h,6);

}